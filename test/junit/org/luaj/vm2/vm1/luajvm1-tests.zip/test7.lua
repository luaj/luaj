local function fixhash(msg)
  return (string.gsub(msg, "@(%x+)", function(s) return "@"..(string.rep("x", 6)) end))
end

obj = luajava.newInstance("java.lang.Object")
print( fixhash( tostring(obj) ) )

sample = luajava.newInstance("java.awt.Rectangle", 20, 30, 40, 50)
print( fixhash( tostring(sample) ) )
sample.width = 200
print( sample.width)
print( sample:getBounds() )

sample:add(300, 400)
print( sample:getBounds() )

math = luajava.bindClass("java.lang.Math")
print("Square root of 9 is", math:sqrt(9.0))
